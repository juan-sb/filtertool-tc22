# Project modules
from src.app import main

if __name__ == "__main__":
    main()
